# ConceptStride — Interactive AI Learning Platform

A student-centered learning hub for AI fundamentals. Built with HTML, CSS, and vanilla JavaScript, with a familiar course-workspace layout and an emphasis on applying concepts and explaining your thinking.

## Use in StackBlitz

Download `dist/conceptstride-stackblitz.zip` and extract it. Replace your existing `index.html`, `styles.css`, `script.js`, and `page2.html` with those files. The included package.json and package-lock.json preserve the Servor setup.

Run `npm install` if needed, then `npm start`. No compilation or API key is required. `page2.html` opens the learning modules for compatibility with the original project.

For this hosted checkout, the web assets are under `dist/`. The downloadable archive places them at the project root for the original StackBlitz setup.

## Working features

- Five AI foundation modules with Learn, Try, and Reflect steps.
- Practice feedback and reflection completion requirements.
- Resume links that keep the current lesson step, including after a reload.
- Practice studio: five recall cards, authored explanations, and self-reported confidence.
- Notebook: six topic spaces, automatic local saving, and word counts.
- Educator preview: create activities, choose assistance policies, review local submissions, and write feedback.
- Student assignment drafts, explicit support disclosures, and visible educator feedback.
- Searchable and filterable modules; links to original learning sources.
- Prompt builder and an illustrative dataset coverage activity.
- Progress and JSON export, including notebook entries and classroom records.
- Responsive navigation, labels, focus states, reduced-motion support, and no required autoplay.

## Scope

Stride Guide is an authored demonstration, not a connected AI model. It provides prewritten concept explanations, examples, and hints. Independent practice pauses the guide within the interface. It does not block other websites, detect AI-generated work, or monitor external browser activity.

Student and educator views are previews that share the current browser's data. They are not authenticated classroom roles. There is no Canvas integration, shared database, cross-device sync, or institutional gradebook. Reflections are saved, not automatically graded. Practice studio confidence is self-assessment and does not complete a module.

The hosted page remains private to its owner. Making it available to recruiters requires a deliberate sharing decision by the owner.

## Data

State is stored in `localStorage` under `conceptstride-learning-v2`. When accessed on the same origin, the app can carry forward the prior `umoja-learning-v2` data. Browser storage does not transfer between different domains. Export a JSON record to keep a copy; import is not implemented.

Exports contain progress, reflections, notebook entries, assignment drafts, submissions, disclosures, feedback, and course settings. No personal information or usage records are bundled in the downloadable source. Clearing browser storage removes the locally stored work.

## Files

- `index.html`: app shell, navigation, guide container, and metadata.
- `styles.css`: visual system and responsive layout.
- `script.js`: lesson content, routing, persistence, study tools, and classroom interactions.
- `page2.html`: compatibility redirect.

Google Fonts and optional original YouTube videos require network access. System font fallbacks and the core activities work without those services.

## Validation of this revision

JavaScript syntax checked with `node --check`. Browser checks covered recall cards, notebook persistence after reload, educator feedback visible to students, saved lesson-step routing, practice grading, and phone-width navigation without horizontal overflow. A new browser starts with an empty learning record; screenshot progress reflects local QA activity.

## Future integration

A production classroom needs server-enforced roles, shared storage, a secure AI endpoint, and a school-approved data and assessment policy. Keep provider API secrets on a server; never place them in these frontend files.
